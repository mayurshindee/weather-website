# 🌤️ Weather Website

A modern, attractive weather website built with **HTML, CSS, and JavaScript** using the **OpenWeatherMap API**.

## 🚀 Features
- Current weather with temperature, condition, wind, humidity, sunrise/sunset
- 5-day forecast (cards)
- Hourly forecast (graph)
- Air Quality Index
- Dark/Light mode
- Detect location (GPS)
- Save favorite cities (localStorage)
- Responsive + Glassmorphism design

## 🛠️ Setup
1. Get a free API key from [OpenWeatherMap](https://openweathermap.org/api).
2. Replace `YOUR_API_KEY` in `js/api.js`.
3. Open `index.html` in your browser.
