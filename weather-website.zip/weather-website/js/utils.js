// Convert Kelvin to Celsius
function toCelsius(temp) {
    return Math.round(temp - 273.15);
  }
  
  // Convert Unix time to HH:MM
  function formatTime(timestamp) {
    const date = new Date(timestamp * 1000);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }
  