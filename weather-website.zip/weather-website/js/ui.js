// Update current weather UI
function updateWeatherUI(data) {
    document.getElementById("cityName").textContent = data.name;
    document.getElementById("temperature").textContent = `🌡️ ${toCelsius(data.main.temp)} °C`;
    document.getElementById("condition").textContent = `☁️ ${data.weather[0].description}`;
    document.getElementById("details").textContent = `💨 Wind: ${data.wind.speed} m/s | 💧 Humidity: ${data.main.humidity}%`;
    document.getElementById("sunTimes").textContent = `🌅 ${formatTime(data.sys.sunrise)} | 🌇 ${formatTime(data.sys.sunset)}`;
  }
  