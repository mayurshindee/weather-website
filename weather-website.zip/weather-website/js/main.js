// 🌍 API Key & Base URL (replace with your own OpenWeatherMap key)
const API_KEY = "b763a56ba7b15b3a44b027380c90700c";
const BASE_URL = "https://api.openweathermap.org/data/2.5/";

// 🔍 Search City Weather
document.getElementById("searchBtn").addEventListener("click", async () => {
  const city = document.getElementById("cityInput").value.trim();

  if (!city) {
    alert("⚠️ Please enter a city name!");
    return;
  }

  const data = await fetchWeather(city);

  if (data && data.cod === 200) {
    updateWeatherUI(data);
    saveFavorite(city);
  } else {
    alert("❌ City not found!");
  }
});

// 📍 Detect User Location
document.getElementById("locationBtn").addEventListener("click", () => {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(async (pos) => {
      const { latitude, longitude } = pos.coords;
      const data = await fetchWeatherByCoords(latitude, longitude);
      if (data && data.cod === 200) {
        updateWeatherUI(data);
      }
    });
  } else {
    alert("❌ Geolocation not supported by this browser.");
  }
});

// 🌗 Theme toggle
document.getElementById("themeToggle").addEventListener("click", () => {
  document.body.classList.toggle("dark");
  document.body.classList.toggle("light");
});

// 🌤️ Fetch Weather by City
async function fetchWeather(city) {
  try {
    const res = await fetch(`${BASE_URL}weather?q=${city}&appid=${API_KEY}&units=metric`);
    return await res.json();
  } catch (err) {
    console.error("API Error:", err);
    return null;
  }
}

// 📍 Fetch Weather by Coordinates
async function fetchWeatherByCoords(lat, lon) {
  try {
    const res = await fetch(`${BASE_URL}weather?lat=${lat}&lon=${lon}&appid=${API_KEY}&units=metric`);
    return await res.json();
  } catch (err) {
    console.error("API Error:", err);
    return null;
  }
}

// 🎨 Update UI with Weather Data
function updateWeatherUI(data) {
  document.getElementById("cityName").textContent = `${data.name}, ${data.sys.country}`;
  document.getElementById("temperature").textContent = `🌡️ ${Math.round(data.main.temp)} °C`;
  document.getElementById("condition").textContent = `${data.weather[0].description}`;
  document.getElementById("details").textContent = `💨 Wind: ${data.wind.speed} m/s | 💧 Humidity: ${data.main.humidity}%`;
  document.getElementById("sunTimes").textContent =
    `🌅 ${new Date(data.sys.sunrise * 1000).toLocaleTimeString()} | 🌇 ${new Date(data.sys.sunset * 1000).toLocaleTimeString()}`;

  // Update weather icon
  const icon = data.weather[0].icon;
  document.getElementById("weatherIcon").src = `https://openweathermap.org/img/wn/${icon}@2x.png`;

  // Change background dynamically
  changeBackground(data.weather[0].main);
}

// 🎨 Dynamic Background based on weather
function changeBackground(condition) {
  let bg;
  switch (condition.toLowerCase()) {
    case "clear": bg = "linear-gradient(to right, #56ccf2, #2f80ed)"; break; // blue sky
    case "clouds": bg = "linear-gradient(to right, #757f9a, #d7dde8)"; break; // cloudy grey
    case "rain": bg = "linear-gradient(to right, #000046, #1cb5e0)"; break; // rainy dark
    case "snow": bg = "linear-gradient(to right, #83a4d4, #b6fbff)"; break; // snowy white-blue
    case "thunderstorm": bg = "linear-gradient(to right, #141e30, #243b55)"; break;
    case "drizzle": bg = "linear-gradient(to right, #89f7fe, #66a6ff)"; break;
    default: bg = "linear-gradient(-45deg, #4facfe, #00f2fe, #43e97b, #f8ffae)";
  }
  document.body.style.background = bg;
  document.body.style.backgroundSize = "400% 400%";
}
