const apiKey = "YOUR_API_KEY"; // Replace with your OpenWeatherMap key

async function fetchWeather(city) {
  const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}`;
  const response = await fetch(url);
  return await response.json();
}
